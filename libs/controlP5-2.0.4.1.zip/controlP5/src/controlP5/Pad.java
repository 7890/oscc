package controlP5;

class Pad {
	// pad for placing controllers, like matrix but without the grid
	// a sequencer
}
